<?php
/**
 * migxcalendars
 *
 * @package migxcalendars
 * @language en
 */

$_lang['migxcal.movetothrash_ifexits'] = 'Move Events to Thrash if not free in this Category';
$_lang['migxcal.on_double_events'] = 'On double events in this category';
$_lang['migxcal.save'] = 'Allow';
$_lang['migxcal.to_thrash'] = 'To Thrash';
$_lang['migxcal.unpublish'] = 'Unpublish';
$_lang['migxcal.ignore'] = 'Ignore';
$_lang['migxcal.assigned_categories'] = 'Assigned Categories';
$_lang['migxcal.category'] = 'Category';
$_lang['migxcal.allday'] = 'All Day';
$_lang['migxcal.unpublish_dates'] = 'Unpublish Dates';
$_lang['migxcal.ondates_in_assigned_cats'] = 'On Dates in assigned Categories';



