<?php
class migxCalendarCalendars extends xPDOSimpleObject {}