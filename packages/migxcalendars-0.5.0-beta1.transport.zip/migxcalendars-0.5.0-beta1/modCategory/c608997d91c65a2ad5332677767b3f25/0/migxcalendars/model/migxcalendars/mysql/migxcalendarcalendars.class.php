<?php
require_once (dirname(dirname(__FILE__)) . '/migxcalendarcalendars.class.php');
class migxCalendarCalendars_mysql extends migxCalendarCalendars {}