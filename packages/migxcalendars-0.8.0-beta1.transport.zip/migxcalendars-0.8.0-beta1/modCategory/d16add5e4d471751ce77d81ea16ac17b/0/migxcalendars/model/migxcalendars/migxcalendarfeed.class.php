<?php
class migxCalendarFeed extends xPDOSimpleObject {}