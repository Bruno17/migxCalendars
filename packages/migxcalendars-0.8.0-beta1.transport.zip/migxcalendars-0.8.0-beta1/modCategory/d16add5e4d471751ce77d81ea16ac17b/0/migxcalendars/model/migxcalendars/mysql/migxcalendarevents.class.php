<?php
require_once (dirname(dirname(__FILE__)) . '/migxcalendarevents.class.php');
class migxCalendarEvents_mysql extends migxCalendarEvents {}