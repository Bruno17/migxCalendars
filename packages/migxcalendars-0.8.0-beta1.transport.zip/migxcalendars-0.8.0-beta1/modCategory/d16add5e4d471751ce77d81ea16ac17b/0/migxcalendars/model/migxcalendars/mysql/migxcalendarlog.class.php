<?php
require_once (dirname(dirname(__FILE__)) . '/migxcalendarlog.class.php');
class migxCalendarLog_mysql extends migxCalendarLog {}