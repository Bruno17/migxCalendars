
migxCalendars


Author: Bruno Perner b.perner@gmx.de
Copyright 2014

Official Documentation: 

Bugs and Feature Requests: https://github.com:Bruno17/migxCalendars

Questions: http://forums.modx.com

Created by MyComponent
