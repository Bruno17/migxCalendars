<?php

$xpdo_meta_map = array (
  'xPDOSimpleObject' => 
  array (
    0 => 'migxCalendarEvents',
    1 => 'migxCalendarDates',
    2 => 'migxCalendarEventImages',
    3 => 'migxCalendarEventVideos',
    4 => 'migxCalendarEventWUG',
    5 => 'migxCalendarCategories',
    6 => 'migxCalendarCalendars',
    7 => 'migxCalendarSettings',
    8 => 'migxCalendarFeed',
    9 => 'migxCalendarLog',
  ),
);