<?php
class migxCalendarCategories extends xPDOSimpleObject {}