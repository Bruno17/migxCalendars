<?php
class migxCalendarEventImages extends xPDOSimpleObject {}