<?php
require_once (dirname(dirname(__FILE__)) . '/migxcalendareventwug.class.php');
class migxCalendarEventWUG_mysql extends migxCalendarEventWUG {}