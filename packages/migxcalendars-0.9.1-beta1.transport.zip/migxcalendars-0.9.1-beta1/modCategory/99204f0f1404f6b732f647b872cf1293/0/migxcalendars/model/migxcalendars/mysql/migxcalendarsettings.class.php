<?php
require_once (dirname(dirname(__FILE__)) . '/migxcalendarsettings.class.php');
class migxCalendarSettings_mysql extends migxCalendarSettings {}