<?php
class migxCalendarEventPeople extends xPDOSimpleObject {}