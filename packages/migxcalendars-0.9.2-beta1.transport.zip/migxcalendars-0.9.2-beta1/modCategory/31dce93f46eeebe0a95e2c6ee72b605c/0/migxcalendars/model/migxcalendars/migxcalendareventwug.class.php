<?php
class migxCalendarEventWUG extends xPDOSimpleObject {}