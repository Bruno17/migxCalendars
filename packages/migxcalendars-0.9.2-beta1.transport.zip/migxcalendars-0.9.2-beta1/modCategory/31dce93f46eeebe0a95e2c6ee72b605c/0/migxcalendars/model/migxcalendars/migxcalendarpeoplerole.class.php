<?php
class migxCalendarPeopleRole extends xPDOSimpleObject {}