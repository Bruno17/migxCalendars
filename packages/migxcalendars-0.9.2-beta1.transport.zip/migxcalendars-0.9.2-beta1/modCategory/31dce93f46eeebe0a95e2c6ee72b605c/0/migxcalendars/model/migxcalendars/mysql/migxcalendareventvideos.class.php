<?php
require_once (dirname(dirname(__FILE__)) . '/migxcalendareventvideos.class.php');
class migxCalendarEventVideos_mysql extends migxCalendarEventVideos {}