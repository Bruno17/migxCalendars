<?php
require_once (dirname(dirname(__FILE__)) . '/migxcalendarcategories.class.php');
class migxCalendarCategories_mysql extends migxCalendarCategories {}