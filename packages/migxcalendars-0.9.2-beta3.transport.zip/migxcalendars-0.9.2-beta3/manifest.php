<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'license' => false,
    'readme' => false,
    'changelog' => false,
    'setup-options' => 
    array (
    ),
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => 'e8f16b75b863b7a117ffc15c37a5fada',
      'native_key' => 'migxcalendars',
      'filename' => 'modNamespace/fa5492d812db464262536be3668650d1.vehicle',
      'namespace' => 'migxcalendars',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => 'efc4054aa0b0ce5bc5b776277820055f',
      'native_key' => 1,
      'filename' => 'modCategory/2906d409081e55c5578c412ed701e51f.vehicle',
      'namespace' => 'migxcalendars',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '33edbdb78e1678ee3473d40f00170f0b',
      'native_key' => 'migxCalendars',
      'filename' => 'modMenu/5335d2ef29116ae081892aa5716cd723.vehicle',
      'namespace' => 'migxcalendars',
    ),
  ),
);