<?php
class migxCalendarLocation extends xPDOSimpleObject {}