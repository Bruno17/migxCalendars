<?php
require_once (dirname(dirname(__FILE__)) . '/migxcalendareventimages.class.php');
class migxCalendarEventImages_mysql extends migxCalendarEventImages {}