<?php
require_once (dirname(dirname(__FILE__)) . '/migxcalendarlocation.class.php');
class migxCalendarLocation_mysql extends migxCalendarLocation {}