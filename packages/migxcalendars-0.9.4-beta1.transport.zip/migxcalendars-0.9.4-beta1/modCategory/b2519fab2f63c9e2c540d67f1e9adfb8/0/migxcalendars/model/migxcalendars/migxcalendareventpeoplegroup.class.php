<?php
class migxCalendarEventPeopleGroup extends xPDOSimpleObject {}