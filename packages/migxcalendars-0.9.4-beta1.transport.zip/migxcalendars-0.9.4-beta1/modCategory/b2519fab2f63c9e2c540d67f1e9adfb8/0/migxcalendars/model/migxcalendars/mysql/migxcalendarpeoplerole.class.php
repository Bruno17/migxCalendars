<?php
require_once (dirname(dirname(__FILE__)) . '/migxcalendarpeoplerole.class.php');
class migxCalendarPeopleRole_mysql extends migxCalendarPeopleRole {}