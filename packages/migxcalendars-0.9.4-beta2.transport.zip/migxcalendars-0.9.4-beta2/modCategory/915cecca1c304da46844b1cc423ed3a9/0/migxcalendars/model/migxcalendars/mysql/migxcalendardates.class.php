<?php
require_once (dirname(dirname(__FILE__)) . '/migxcalendardates.class.php');
class migxCalendarDates_mysql extends migxCalendarDates {}