<?php
require_once (dirname(dirname(__FILE__)) . '/migxcalendarfeed.class.php');
class migxCalendarFeed_mysql extends migxCalendarFeed {}