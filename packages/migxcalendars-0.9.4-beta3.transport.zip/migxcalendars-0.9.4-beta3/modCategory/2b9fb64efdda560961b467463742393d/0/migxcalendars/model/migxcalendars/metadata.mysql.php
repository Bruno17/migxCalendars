<?php

$xpdo_meta_map = array (
  'xPDOSimpleObject' => 
  array (
    0 => 'migxCalendarEvents',
    1 => 'migxCalendarDates',
    2 => 'migxCalendarEventImages',
    3 => 'migxCalendarEventVideos',
    4 => 'migxCalendarEventPeople',
    5 => 'migxCalendarPeopleRole',
    6 => 'migxCalendarEventPeopleGroup',
    7 => 'migxCalendarLocation',
    8 => 'migxCalendarEventWUG',
    9 => 'migxCalendarCategories',
    10 => 'migxCalendarCalendars',
    11 => 'migxCalendarSettings',
    12 => 'migxCalendarFeed',
    13 => 'migxCalendarLog',
  ),
);