<?php
class migxCalendarEventVideos extends xPDOSimpleObject {}