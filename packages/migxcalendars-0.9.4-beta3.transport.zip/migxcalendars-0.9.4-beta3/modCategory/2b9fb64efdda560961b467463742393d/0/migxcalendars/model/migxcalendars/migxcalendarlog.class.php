<?php
class migxCalendarLog extends xPDOSimpleObject {}