<?php
class migxCalendarSettings extends xPDOSimpleObject {}