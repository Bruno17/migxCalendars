<?php
require_once (dirname(dirname(__FILE__)) . '/migxcalendareventpeople.class.php');
class migxCalendarEventPeople_mysql extends migxCalendarEventPeople {}