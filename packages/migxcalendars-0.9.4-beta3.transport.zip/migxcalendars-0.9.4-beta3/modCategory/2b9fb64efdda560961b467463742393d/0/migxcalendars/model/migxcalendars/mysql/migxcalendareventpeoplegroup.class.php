<?php
require_once (dirname(dirname(__FILE__)) . '/migxcalendareventpeoplegroup.class.php');
class migxCalendarEventPeopleGroup_mysql extends migxCalendarEventPeopleGroup {}